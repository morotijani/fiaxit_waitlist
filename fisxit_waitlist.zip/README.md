# fisxit_waitlist
A waitlist for fiaxit (crypto exchange platform).
